console.log("Register page");
let saloon={
    name:"The Fashion Pet",
    address:{
        street:"University",
        number:"758-K",
        zip:"22569",
        city:"San Diego",
    },
    hours:{
        open:"9:00 am",
        close:"20:00 pm"
    },
    pets:[
        {
        name:"Scooby",
        age:6,
        gender:"Male",
        breed:"Dane",
        services:"Grooming",
        owner:"Shaggy",
        phone:"666-666-6666",
        },
        {
            name:"Scrappy",
            age:5,
            gender:"male",
            breed:"Mixed",
            service:"Nail but",
            owner:"Shaggy",
            phone:"666-666-6666",

        },
        {
            name:"Cherry",
            age:10,
            gender:"male",
            breed:"Bulldog",
            service:"wash but",
            owner:"Shaggy",
            phone:"666-666-6666",

        },
        {
            name:"Fluffy",
            age:6,
            gender:"male",
            breed:"boxer",
            service:"grooming but",
            owner:"Shaggy",
            phone:"666-666-6666",

        }
    ]
}
console.log(saloon.address.city);
console.log(saloon.pets);

alert(saloon.pets.length+ "registered pets");

function simpleDisplay(){
    //display the name of the pets(4)
for(i=0;i<saloon.pets.length;i++){ 
    console.log(saloon.pets[i].name);
    }
}
simpleDisplay();